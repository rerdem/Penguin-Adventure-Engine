The Penguin Adventure Engine
-------------------------------
The Penguin Adventure Engine is a simple game engine
for Choose-Your-Own-Adventure type stories.
It is written in C++ using Qt.
-------------------------------
For more information visit skypenguins.com